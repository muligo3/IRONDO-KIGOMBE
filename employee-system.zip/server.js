const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const employeesRouter = require('./routes/employees');
const deductionsRouter = require('./routes/deductions');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/employees', employeesRouter);
app.use('/api/deductions', deductionsRouter);

// Health
app.get('/api/health', (req, res) => res.json({status: 'ok'}));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
