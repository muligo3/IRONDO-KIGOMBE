# Employee Management Backend (Node.js + Express + SQLite)

## What's included
- Simple REST API for employees and deductions.
- SQLite database file created at `data/employees.db`.
- Migrations SQL at `migrations/init.sql`.
- Seed data in `seeds/seed.sql`.

## Setup (on your machine)
1. Ensure Node.js >= 16 is installed.
2. In the project folder, run:
   ```
   npm install
   node -e "const db=require('./db'); const fs=require('fs'); const sql=require('fs').readFileSync('./migrations/init.sql','utf8'); db.exec(sql, ()=>{console.log('migrations run')});"
   ```
   Note: the above command will initialize the DB.
3. Optionally run seeds:
   ```
   node -e "const db=require('./db'); const fs=require('fs'); const sql=require('fs').readFileSync('./seeds/seed.sql','utf8'); db.exec(sql, ()=>{console.log('seeds applied')});"
   ```
4. Start the server:
   ```
   npm start
   ```
5. API endpoints:
   - `GET /api/employees` - list active employees
   - `POST /api/employees` - create employee
   - `GET /api/employees/:id` - get employee
   - `PUT /api/employees/:id` - update employee
   - `DELETE /api/employees/:id` - delete permanently
   - `POST /api/employees/archive/:id` - archive (soft-delete)
   - `GET /api/employees/archived/all` - list archived
   - `GET /api/deductions` - list deductions
   - `POST /api/deductions/apply` - apply deduction by status
