-- Initialize employees table
CREATE TABLE IF NOT EXISTS employees (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  status TEXT NOT NULL,
  employee_id TEXT UNIQUE NOT NULL,
  telephone TEXT UNIQUE NOT NULL,
  village TEXT,
  bank_number TEXT UNIQUE NOT NULL,
  working_days INTEGER DEFAULT 0,
  base_amount REAL DEFAULT 0,
  deduction REAL DEFAULT 0,
  amount REAL DEFAULT 0,
  active INTEGER DEFAULT 1,
  archived_reason TEXT,
  archived_date TEXT
);
