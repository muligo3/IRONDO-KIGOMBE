-- Optional seed data for testing
INSERT OR IGNORE INTO employees (id, name, status, employee_id, telephone, village, bank_number, working_days, base_amount, deduction, amount, active)
VALUES
('00000000-0000-0000-0000-000000000001', 'Alice Example', 'Staff Member', '0000000000000001', '0780000001', 'Village A', 'BNK0001', 20, 40000, 0, 40000, 1),
('00000000-0000-0000-0000-000000000002', 'Bob Example', 'Cell Commander', '0000000000000002', '0780000002', 'Village B', 'BNK0002', 30, 100000, 0, 100000, 1);
