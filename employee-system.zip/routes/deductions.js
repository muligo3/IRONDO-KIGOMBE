const express = require('express');
const router = express.Router();
const db = require('../db');

// get deductions by status (aggregate)
router.get('/', (req, res) => {
  db.all('SELECT status, AVG(deduction) as avg_deduction FROM employees GROUP BY status', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Internal server error' });
    res.json(rows || []);
  });
});

// apply deduction for a status
router.post('/apply', (req, res) => {
  const { status, deduction } = req.body;
  if (!status || deduction === undefined) return res.status(400).json({ error: 'status and deduction required' });
  const sql = 'UPDATE employees SET deduction = ?, amount = base_amount - ? WHERE status = ?';
  db.run(sql, [deduction, deduction, status], function(err) {
    if (err) return res.status(500).json({ error: 'Internal server error' });
    res.json({ success: true, rowsAffected: this.changes });
  });
});

module.exports = router;
