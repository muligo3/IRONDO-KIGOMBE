const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');

// Helper to run SQL with promise
function run(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}
function all(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}
function get(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

// Create employee
router.post('/', async (req, res) => {
  try {
    const { name, status, employee_id, telephone, village, bank_number, working_days } = req.body;
    if (!name || !status || !employee_id || !telephone || !bank_number) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    if (String(employee_id).length !== 16) return res.status(400).json({ error: 'employee_id must be 16 characters' });
    if (String(telephone).length !== 10) return res.status(400).json({ error: 'telephone must be 10 characters' });

    // check unique constraints
    const exists = await get('SELECT id FROM employees WHERE employee_id = ? OR telephone = ? OR bank_number = ?', [employee_id, telephone, bank_number]);
    if (exists) return res.status(409).json({ error: 'employee_id, telephone or bank_number already exists' });

    const id = uuidv4();
    const base_amount = (status === 'Cell Commander') ? 100000 : (status === 'Accountant') ? 80000 : (working_days ? working_days*2000 : 0);
    const deduction = 0;
    const amount = Math.max(0, base_amount - deduction);
    const sql = `INSERT INTO employees (id, name, status, employee_id, telephone, village, bank_number, working_days, base_amount, deduction, amount, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`;
    await run(sql, [id, name, status, employee_id, telephone, village, bank_number, working_days || 0, base_amount, deduction, amount]);
    const created = await get('SELECT * FROM employees WHERE id = ?', [id]);
    res.status(201).json(created);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all active employees
router.get('/', async (req, res) => {
  try {
    const rows = await all('SELECT * FROM employees WHERE active = 1 ORDER BY name COLLATE NOCASE');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single
router.get('/:id', async (req, res) => {
  try {
    const row = await get('SELECT * FROM employees WHERE id = ?', [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const { name, status, telephone, village, bank_number, working_days } = req.body;
    const id = req.params.id;
    const employee = await get('SELECT * FROM employees WHERE id = ?', [id]);
    if (!employee) return res.status(404).json({ error: 'Not found' });
    const base_amount = (status === 'Cell Commander') ? 100000 : (status === 'Accountant') ? 80000 : (working_days ? working_days*2000 : employee.base_amount);
    const deduction = employee.deduction || 0;
    const amount = Math.max(0, base_amount - deduction);
    await run(`UPDATE employees SET name=?, status=?, telephone=?, village=?, bank_number=?, working_days=?, base_amount=?, amount=? WHERE id=?`,
      [name||employee.name, status||employee.status, telephone||employee.telephone, village||employee.village, bank_number||employee.bank_number, working_days||employee.working_days, base_amount, amount, id]);
    const updated = await get('SELECT * FROM employees WHERE id = ?', [id]);
    res.json(updated);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Archive (soft-delete) with reason
router.post('/archive/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const { reason } = req.body;
    const emp = await get('SELECT * FROM employees WHERE id = ?', [id]);
    if (!emp) return res.status(404).json({ error: 'Not found' });
    await run('UPDATE employees SET active=0, archived_reason=?, archived_date=CURRENT_TIMESTAMP WHERE id=?', [reason||null, id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Permanently delete
router.delete('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    await run('DELETE FROM employees WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get archived
router.get('/archived/all', async (req, res) => {
  try {
    const rows = await all('SELECT * FROM employees WHERE active = 0 ORDER BY archived_date DESC');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
